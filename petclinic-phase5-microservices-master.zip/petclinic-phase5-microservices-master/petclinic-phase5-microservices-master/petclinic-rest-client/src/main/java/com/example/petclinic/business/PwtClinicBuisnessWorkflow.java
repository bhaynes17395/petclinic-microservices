package com.example.petclinic.business;

import com.example.petclinic.PetClinicClient;
import com.example.petclinic.service.OwnerService;

public class PwtClinicBuisnessWorkflow {

    OwnerService ownerService;

    public PetClinicBuisnessWorkflow(OwnerService ownerService)
    {
        this.ownerService = ownerService;
    }
    public void runBusiness()
    {
        Owner owner1 = 
    }
}
