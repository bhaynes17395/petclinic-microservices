package com.example.petclinic.service;

import com.example.petclinic.model.Owner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@Service
public class OwnerService {
    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    private RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Owner saveOwner(Owner owner)
    {
        URI uri = URI.create("http://localhost:9091/petclinic/owner/addOwner");
        Owner response = restTemplate.postForObject(uri,owner,Owner.class);
        log.info(response.toString());
        return response;
    }
    public Owner deleateOwner(Owner owner)
    {
        return owner;
    }

    public List<Owner> getAllOwner()
    {
        URI uri = URI.create("http://localhost:9091/petclinic/owner/getAllOwners");
        List<Owner> response = restTemplate.getForObject(uri, List.class);
        log.info(response.toString());
        return response;
    }
    public Owner getOwnerByName(String name)
    {
        name.replaceAll(" ", "%20");
        URI uri = URI.create("http://localhost:9091/petclinic/owner/getOwnerByName");
        List<Owner> response = restTemplate.getForObject(uri,List.class);
        log.info(response.toString());
        return response.get(0);
    }
}
